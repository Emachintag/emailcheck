from flask import Flask, render_template, request
import whois
import socket
import ssl
import re
import dns.resolver
import requests
import subprocess
import sys
from datetime import datetime

app = Flask(__name__)

# SSL Sertifikası kontrol fonksiyonu
def check_ssl(domain):
    try:
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443)) as sock:
            with context.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                return cert
    except:
        return None

# Whois bilgisine bakarak alan adı yaşı kontrolü
def check_whois(domain):
    try:
        w = whois.whois(domain)
        creation_date = w.creation_date
        if isinstance(creation_date, list):
            creation_date = creation_date[0]
        age = (datetime.now() - creation_date).days / 365
        return age > 1  # 1 yıldan kısa mı kontrol
    except:
        return False

# DNS kontrolü
def check_dns(domain):
    try:
        answers = dns.resolver.resolve(domain, 'A')
        return [answer.to_text() for answer in answers]
    except:
        return None

# Coming Soon veya Under Maintenance kontrolü
def check_coming_soon(domain):
    try:
        url = f"http://{domain}"
        response = requests.get(url, timeout=10)  # Web sayfasına istek gönder
        if response.status_code == 200:  # Sayfa bulunduysa
            content = response.text.lower()
            if "coming soon" in content or "under maintenance" in content or "bakımda" in content or "yakında gelecek" in content:
                return True  # Sayfa bakım modunda
        return False
    except requests.RequestException:
        return False  # İstek başarısız olduysa False döndür

# Web sitesi boyutu kontrolü
def check_site_size(domain):
    try:
        url = f"http://{domain}"
        response = requests.get(url, timeout=10)
        content_length = response.headers.get('Content-Length')
        if content_length:
            size_mb = int(content_length) / (1024 * 1024)  # Byte'ı MB'a çeviriyoruz
        else:
            size_mb = len(response.content) / (1024 * 1024)  # Content-Length yoksa body boyutunu al
        return size_mb
    except requests.RequestException:
        return None

# Anahtar kelime kontrolü
def check_domain_keywords(email, domain):
    keywords = ['darkweb', 'hunting', 'intel', 'alumni', 'alumna', 'std', 'student', 'free', 'temp']
    for keyword in keywords:
        if keyword in email or keyword in domain:  # Hem e-posta hem domain içinde arıyoruz
            return True
    return False

# Türkçe argo/küfür içerik kontrolü
def load_turkish_slang_words(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            slang_words = [line.strip() for line in file.readlines()]  # Her satırı al, trim et
        return slang_words
    except FileNotFoundError:
        return []

def check_turkish_slang(email, domain, slang_words):
    for slang in slang_words:
        if slang in email or slang in domain:
            return True
    return False

# E-posta formatı kontrolü
def validate_email_format(email):
    regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return re.match(regex, email) is not None

# Mail adresinde ve domaininde rakam kontrolü (360, 724, 247, 101 hariç)
def check_digit_count(email, domain):
    exempt_numbers = ['360', '724', '247', '101']
    
    email_digits = re.findall(r'\d+', email)
    domain_digits = re.findall(r'\d+', domain)
    
    def count_valid_digits(digits):
        valid_digits = [d for d in digits if d not in exempt_numbers]
        return sum(len(d) for d in valid_digits)
    
    email_digit_count = count_valid_digits(email_digits)
    domain_digit_count = count_valid_digits(domain_digits)
    
    return (email_digit_count > 2) or (domain_digit_count > 2)

# Disposable email kontrol fonksiyonu
def check_disposable_email(email):
    api_urls = {
        "Kickbox": f"https://open.kickbox.com/v1/disposable/{email}",
        "MailCheck": f"https://api.mailcheck.ai/email/{email}",
        "IsItRealEmail": f"https://isitarealemail.com/api/email/validate?email={email}",
        "Disify": f"https://checkmail.disify.com/api/email/{email}",
        "ValidatorPizza": f"https://www.validator.pizza/email/{email}",
    }
    
    results = {}
    disposable_count = 0
    not_disposable_count = 0

    for api_name, url in api_urls.items():
        try:
            response = requests.get(url)
            data = response.json()
            if "disposable" in data:
                results[api_name] = data['disposable']
            elif "valid" in data:
                results[api_name] = not data['valid']
            elif "status" in data:
                results[api_name] = data["status"] == "invalid"
            elif "deliverable" in data:
                results[api_name] = not data['deliverable']
            else:
                results[api_name] = "unknown"

            if results[api_name]:
                disposable_count += 1
            else:
                not_disposable_count += 1
        except Exception as e:
            results[api_name] = f"Error: {str(e)}"
    
    return results, disposable_count, not_disposable_count

# Puanlama Sistemi
def calculate_score(email, domain):
    score = 100

    cert = check_ssl(domain)
    if cert and 'Let\'s Encrypt' in cert['issuer'][0]:
        score -= 15

    local_part = email.split('@')[0]
    if re.match(r'^[a-zA-Z]+$', local_part) is None:
        score -= 20

    return score

# Kontrol ve Puanlama Sistemi
def evaluate_email(email):
    domain = email.split('@')[1]
    results = []
    failed_checks = []  # Başarısız olunan kontrolleri toplamak için

    slang_file_path = 'turkish_slang.txt'
    slang_words = load_turkish_slang_words(slang_file_path)

    # 1. Whois kontrolü
    whois_check = check_whois(domain)
    if not whois_check:
        failed_checks.append('Whois Kontrolü')
    results.append({
        'title': 'Whois Kontrolü',
        'content': f"Domain {'1 yıldan fazla' if whois_check else '1 yıldan kısa'} süredir aktif.",
        'status': 'success' if whois_check else 'fail'
    })

    # 2. SSL kontrolü
    ssl_check = check_ssl(domain)
    if not ssl_check:
        failed_checks.append('SSL Kontrolü')
    results.append({
        'title': 'SSL Durumu',
        'content': 'Sertifika mevcut.' if ssl_check else 'Sertifika yok.',
        'status': 'success' if ssl_check else 'fail'
    })

    # 3. DNS Kontrolü
    dns_check = check_dns(domain)
    if not dns_check:
        failed_checks.append('DNS Kontrolü')
    results.append({
        'title': 'DNS Durumu',
        'content': f"DNS çözümleme başarılı: {', '.join(dns_check)}" if dns_check else 'DNS çözümleme başarısız.',
        'status': 'success' if dns_check else 'fail'
    })

    # 4. Coming Soon Kontrolü
    coming_soon_check = check_coming_soon(domain)
    if coming_soon_check:
        failed_checks.append('Coming Soon Kontrolü')
    results.append({
        'title': 'Coming Soon Kontrolü',
        'content': 'Site bakım modunda.' if coming_soon_check else 'Site aktif.',
        'status': 'fail' if coming_soon_check else 'success'
    })

    # 5. Web Sitesi Boyutu Kontrolü
    site_size = check_site_size(domain)
    if site_size and site_size < 1:
        failed_checks.append('Web Sitesi Boyutu')
    results.append({
        'title': 'Web Sitesi Boyutu',
        'content': f"Site boyutu: {site_size:.2f} MB" if site_size else 'Site boyutu alınamadı.',
        'status': 'fail' if site_size and site_size < 1 else 'success'
    })

    # 6. Anahtar Kelime Kontrolü
    keyword_check = check_domain_keywords(email, domain)
    if keyword_check:
        failed_checks.append('Anahtar Kelime Kontrolü')
    results.append({
        'title': 'Anahtar Kelime Kontrolü',
        'content': 'Yasaklı anahtar kelimeler içeriyor.' if keyword_check else 'Yasaklı anahtar kelimeler yok.',
        'status': 'fail' if keyword_check else 'success'
    })

    # 7. Türkçe Argo/Küfür Kontrolü
    slang_check = check_turkish_slang(email, domain, slang_words)
    if slang_check:
        failed_checks.append('Argo/Küfür Kontrolü')
    results.append({
        'title': 'Argo/Küfür Kontrolü',
        'content': 'Argo veya küfür içeriyor.' if slang_check else 'Argo veya küfür yok.',
        'status': 'fail' if slang_check else 'success'
    })

    # 8. E-posta Formatı Kontrolü
    format_check = validate_email_format(email)
    if not format_check:
        failed_checks.append('E-posta Formatı Kontrolü')
    results.append({
        'title': 'E-posta Formatı Kontrolü',
        'content': 'E-posta formatı uygun.' if format_check else 'E-posta formatı yanlış.',
        'status': 'success' if format_check else 'fail'
    })

    # 9. Rakam Kontrolü
    digit_check = check_digit_count(email, domain)
    if digit_check:
        failed_checks.append('Rakam Kontrolü')
    results.append({
        'title': 'Rakam Kontrolü',
        'content': 'E-posta adresi veya domain 2\'den fazla rakam içeriyor.' if digit_check else '2\'den fazla rakam içermiyor.',
        'status': 'fail' if digit_check else 'success'
    })

    # 10. Disposable E-posta Kontrolü
    disposable_results, disposable_count, not_disposable_count = check_disposable_email(email)
    disposable_status = [f"{api_name}: {'Disposable' if result else 'Not Disposable'}" for api_name, result in disposable_results.items()]
    if disposable_count > not_disposable_count:
        failed_checks.append('Disposable E-posta Kontrolü')
    results.append({
        'title': 'Disposable E-posta Kontrolü',
        'content': ', '.join(disposable_status),
        'status': 'fail' if disposable_count > not_disposable_count else 'success'
    })

    # 11. Puan hesaplama
    score = calculate_score(email, domain)
    if not failed_checks:
        results.append({
            'title': 'Puanlama',
            'content': f"E-posta için toplam puan: {score}",
            'status': 'success'
        })
    else:
        results.append({
            'title': 'Başarısız Kontroller',
            'content': f"Başarısız olunan kontroller: {', '.join(failed_checks)}",
            'status': 'fail'
        })
        results.append({
            'title': 'Puanlama',
            'content': f"E-posta için toplam puan: {score}",
            'status': 'success'
        })

    return results

# Kütüphaneleri kontrol edip yükleme fonksiyonu
def install_libraries():
    required_libraries = ['whois', 'requests', 'dns', 'colorama']
    missing_libraries = []

    for library in required_libraries:
        try:
            __import__(library)
        except ImportError:
            missing_libraries.append(library)

    if missing_libraries:
        for library in missing_libraries:
            subprocess.check_call([sys.executable, "-m", "pip", "install", library])

    return missing_libraries

# Kütüphaneleri kontrol eden route
@app.route('/check_libraries', methods=['GET'])
def check_libraries():
    missing_libraries = install_libraries()
    if missing_libraries:
        return f"Kütüphaneler yüklendi: {', '.join(missing_libraries)}"
    else:
        return "Tüm kütüphaneler zaten yüklü."

# Ana sayfa (e-posta girişi)
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        email = request.form['email']
        results = evaluate_email(email)
        return render_template('result.html', results=results)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
